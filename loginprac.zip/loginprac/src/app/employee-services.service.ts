import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServicesService implements OnInit {

  constructor(private http: HttpClient) { }
  url = "http://localhost:3000/EmployeeDetails"

  //get employee Data
  getEmployeeList() {
    return this.http.get(this.url);
  }
  AddEmployeeData(){
    // this.http.post(this.url);
  }
  ngOnInit(): void {
  }
}

